filter_cfg = dict(
    type='OneEuroFilter',
    min_cutoff=0.004,
    beta=0.7,
)
