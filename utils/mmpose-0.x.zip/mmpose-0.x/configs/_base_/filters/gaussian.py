filter_cfg = dict(
    type='GaussianFilter',
    window_size=11,
    sigma=4.0,
)
